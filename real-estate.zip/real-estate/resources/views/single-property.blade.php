@extends('layouts.main')

@section('content')
1
  @include('components.form-search')
  @include('components.single-property.intro')
  @include('components.single-property.details')

@stop
