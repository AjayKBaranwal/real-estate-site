<?php

namespace App\Repositories;

interface LanguageRepositoryInterface extends EloquentRepositoryInterface {}
