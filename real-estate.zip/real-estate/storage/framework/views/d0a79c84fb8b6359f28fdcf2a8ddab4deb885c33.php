<div class="click-closed"></div>
<!--/ Form Search Star /-->
<div class="box-collapse">
  <div class="title-box-d">
    <h3 class="title-d"><?php echo e(__('Search Property')); ?></h3>
  </div>
  <span class="close-box-collapse right-boxed ion-ios-close"></span>
  <div class="box-collapse-wrap form">
    <form class="form-a" action="/<?php echo e(app()->currentLocale()); ?>/search" method="GET">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-md-6 mb-2">
          <div class="form-group">
            <label for="Type"><?php echo e(__('Type')); ?></label>
            <select name="type" class="form-control form-control-lg form-control-a" id="Type">
              <option>Any</option>
              <?php $__currentLoopData = $filters["types"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($type); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="col-md-6 mb-2">
          <div class="form-group">
            <label for="city"><?php echo e(__('City')); ?></label>
            <select name="city" class="form-control form-control-lg form-control-a" id="city">
              <option>Any</option>
              <?php $__currentLoopData = $filters["cities"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($city); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="col-md-6 mb-2">
          <div class="form-group">
            <label for="bedrooms"><?php echo e(__('Beds')); ?></label>
            <select name="beds" class="form-control form-control-lg form-control-a" id="bedrooms">
              <option>Any</option>
              <?php $__currentLoopData = $filters["beds"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bedNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($bedNum); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="col-md-6 mb-2">
          <div class="form-group">
            <label for="garages"><?php echo e(__('Garages')); ?></label>
            <select name="garages" class="form-control form-control-lg form-control-a" id="garages">
              <option>Any</option>
              <?php $__currentLoopData = $filters["garages"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($garageNum); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="col-md-6 mb-2">
          <div class="form-group">
            <label for="bathrooms"><?php echo e(__('Bathrooms')); ?></label>
            <select name="bathrooms" class="form-control form-control-lg form-control-a" id="bathrooms">
              <option>Any</option>
              <?php $__currentLoopData = $filters["baths"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bathNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($bathNum); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class="col-md-6 mb-2">
          <div class="form-group">
            <label for="price"><?php echo e(__('Min Price')); ?> (USD)</label>
            <input type="text" name="minPrice" value="" id="price" placeholder="Unlimited" class="form-control form-control-lg form-control-a">
          </div>
        </div>
        <div class="col-md-12">
          <button type="submit" class="btn btn-b"><?php echo e(__('Search Property')); ?></button>
        </div>
      </div>
    </form>
  </div>
</div>
<!--/ Form Search End /-->
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/components/form-search.blade.php ENDPATH**/ ?>