<div class="row mt-5">
    <div class="col-12">
      <h5 class="card-header p-0"><?php echo e(__('Upload images')); ?></h5>
    </div>
</div>
<div class="form-group row mt-2">
  <div class="col-12">
    <label for="vertical-image"><?php echo e(__('Select a')); ?> <b><?php echo e(__('one vertical image')); ?></b><br>(image 600 x 800):</label><br>
    <input class="mt-2" type="file" id="vertical-image" name="verticalImage">
  </div>
</div>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/add-property/vertical-image.blade.php ENDPATH**/ ?>