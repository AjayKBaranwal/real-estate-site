<form id="add-testemonial-form" data-parsley-validate="" novalidate=""
  method="POST"
  enctype="multipart/form-data"
  action="/home/testemonial">
  <?php echo csrf_field(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Name(s)')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="names" type="text" placeholder="Name" class="form-control">
        </div>
    </div>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Text')); ?> (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-text" class="form-control"></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row mt-5">
        <div class="col-12">
          <h5 class="card-header p-0"><?php echo e(__('Upload images')); ?></h5>
        </div>
    </div>
    <div class="form-group row mt-3">
      <div class="col-12">
        <label for="big-image"><?php echo e(__('Select a image')); ?> (image 650 x 450):</label><br>
        <input type="file" id="big-image" name="big-image">
      </div>
    </div>
    <div class="form-group row mt-3">
      <div class="col-12">
        <label for="mini-image"><?php echo e(__('Select small image')); ?> (image 80 x 80):</label><br>
        <input type="file" id="mini-image" name="mini-image">
      </div>
    </div>
    <div class="form-group row text-right">
        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
            <button
              type="submit"
              class="btn btn-space btn-primary">
              <?php echo e(__('Save')); ?>

            </button>
        </div>
    </div>
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/add-testemonial/form.blade.php ENDPATH**/ ?>