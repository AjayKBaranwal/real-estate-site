@extends('layouts.main')

@section('content')

  @include('components.form-search')
  @include('components.properties.title')
  @include('components.properties.property_grid')

@stop
