<?php

namespace App\Repositories;

interface AboutRepositoryInterface extends EloquentRepositoryInterface {}
