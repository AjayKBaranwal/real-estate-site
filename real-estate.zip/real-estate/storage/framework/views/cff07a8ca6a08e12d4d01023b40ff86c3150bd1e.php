<!--/ Agent Single Star /-->
<section class="agent-single">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="row">
          <div class="col-md-6">
            <div class="agent-avatar-box">
              <img src="<?php echo e(asset('images/agent_images').'/'.$agent->image); ?>" alt="" class="agent-avatar img-fluid">
            </div>
          </div>
          <div class="col-md-5 section-md-t3">
            <div class="agent-info-box">
              <div class="agent-title">
                <div class="title-box-d">
                  <h3 class="title-d">
                    <?php echo e($agent->full_name); ?>

                  </h3>
                </div>
              </div>
              <div class="agent-content mb-3">
                <p class="content-d color-text-a">
                  <?php echo e($agent->about); ?>

                </p>
                <div class="info-agents color-a">
                  <p>
                    <strong><?php echo e(__('Phone')); ?>: </strong>
                    <span class="color-text-a"><?php echo e($agent->phone); ?></span>
                  </p>
                  <p>
                    <strong><?php echo e(__('Email')); ?>: </strong>
                    <span class="color-text-a"> <?php echo e($agent->email); ?></span>
                  </p>
                </div>
              </div>
              <div class="socials-footer">
                <ul class="list-inline">
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-instagram" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-dribbble" aria-hidden="true"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-12 section-t8">
        <div class="title-box-d">
          <h3 class="title-d"><?php echo e(__('My Properties')); ?> (<?php echo e($agent->properties->count()); ?>)</h3>
        </div>
      </div>
      <div
      class="row property-grid grid"
      <?php if($agent->properties->count() == 1): ?>
      style="width: 100%;"
      <?php endif; ?>
      >
        <?php $__currentLoopData = $agent->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="card-box-a card-shadow">
            <div class="img-box-a">
              <img src="<?php echo e(asset('images/property_images/vertical_images/'.$property->vertical_image)); ?>" alt="" class="img-a img-fluid">
            </div>
            <div class="card-overlay">
              <div class="card-overlay-a-content">
                <div class="card-header-a">
                  <h2 class="card-title-a">
                    <a href="/<?php echo e(app()->currentLocale()); ?>/property/<?php echo e($property->id); ?>">
                      <?php echo e($property->city); ?>

                    </a>
                  </h2>
                </div>
                <div class="card-body-a">
                  <div class="price-box d-flex">
                    <span class="price-a">rent | $ <?php echo e($property->rent); ?></span>
                  </div>
                  <a href="/<?php echo e(app()->currentLocale()); ?>/property/<?php echo e($property->id); ?>" class="link-a">
                    <?php echo e(__('Click here to view')); ?>

                    <span class="ion-ios-arrow-forward"></span>
                  </a>
                </div>
                <div class="card-footer-a">
                  <ul class="card-info d-flex justify-content-around">
                    <li>
                      <h4 class="card-info-title"><?php echo e(__('Area')); ?></h4>
                      <span><?php echo e($property->area); ?>m
                        <sup>2</sup>
                      </span>
                    </li>
                    <li>
                      <h4 class="card-info-title"><?php echo e(__('Beds')); ?></h4>
                      <span><?php echo e($property->beds); ?></span>
                    </li>
                    <li>
                      <h4 class="card-info-title"><?php echo e(__('Baths')); ?></h4>
                      <span><?php echo e($property->baths); ?></span>
                    </li>
                    <li>
                      <h4 class="card-info-title"><?php echo e(__('Garages')); ?></h4>
                      <span><?php echo e($property->garage); ?></span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</section>
<!--/ Agent Single End /-->
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/components/single-agent/agent-details.blade.php ENDPATH**/ ?>