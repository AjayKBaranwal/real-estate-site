<?php $__env->startSection('content'); ?>

<?php if(session()->has('successMessage')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('successMessage')); ?>

    </div>
<?php endif; ?>

<?php echo $__env->make('adminpanel.components.agents_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminpanel.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/agents.blade.php ENDPATH**/ ?>