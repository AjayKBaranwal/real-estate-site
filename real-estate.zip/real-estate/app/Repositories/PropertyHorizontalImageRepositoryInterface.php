<?php

namespace App\Repositories;

interface PropertyHorizontalImageRepositoryInterface extends EloquentRepositoryInterface {}
