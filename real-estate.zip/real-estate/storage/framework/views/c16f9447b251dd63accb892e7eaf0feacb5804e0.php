<div class="row">
    <!-- basic table  -->
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header"><?php echo e(__('Table of agents')); ?></h5>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered first">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Full name')); ?></th>
                                <th><?php echo e(__('Phone')); ?></th>
                                <th><?php echo e(__('Email')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($agent->full_name); ?></td>
                                <td><?php echo e($agent->phone); ?></td>
                                <td><?php echo e($agent->email); ?></td>
                                <td>
                                  <a href="/home/agent/<?php echo e($agent->id); ?>">
                                    <?php echo e(__('Edit')); ?> <i class="pl-2 fas fa-edit"></i>
                                  </a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- end basic table  -->
</div>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/agents_table.blade.php ENDPATH**/ ?>