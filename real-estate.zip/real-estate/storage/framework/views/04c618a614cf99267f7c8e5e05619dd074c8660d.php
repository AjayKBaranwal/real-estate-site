<!--/ Property Star /-->
<section class="section-property section-t8">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="title-wrap d-flex justify-content-between">
          <div class="title-box">
            <h2 class="title-a"><?php echo e(__('Latest Properties')); ?></h2>
          </div>
          <div class="title-link">
            <a href="/<?php echo e(app()->currentLocale()); ?>/properties"><?php echo e(__('All Property')); ?>

              <span class="ion-ios-arrow-forward"></span>
            </a>
          </div>
        </div>
      </div>
    </div>
    <div id="property-carousel" class="owl-carousel owl-theme">
      <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item-b">
        <div class="card-box-a card-shadow">
          <div class="img-box-a">
            <img src="<?php echo e(asset('/public/images/property_images/vertical_images/'.$property->vertical_image)); ?>" alt="" class="img-a img-fluid">
          </div>
          <div class="card-overlay">
            <div class="card-overlay-a-content">
              <div class="card-header-a">
                <h2 class="card-title-a">
                  <a href="/<?php echo e(app()->currentLocale()); ?>/property/<?php echo e($property->id); ?>">
                    <?php echo e($property->city); ?>

                    <br /> <?php echo e($property->street_name); ?></a>
                </h2>
              </div>
              <div class="card-body-a">
                <div class="price-box d-flex">
                  <span class="price-a">rent | $ <?php echo e($property->rent); ?></span>
                </div>
                <a href="/<?php echo e(app()->currentLocale()); ?>/property/<?php echo e($property->id); ?>" class="link-a"><?php echo e(__('Click here to view')); ?>

                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
              <div class="card-footer-a">
                <ul class="card-info d-flex justify-content-around">
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Area')); ?></h4>
                    <span><?php echo e($property->area); ?>m
                      <sup>2</sup>
                    </span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Beds')); ?></h4>
                    <span><?php echo e($property->beds); ?></span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Baths')); ?></h4>
                    <span><?php echo e($property->baths); ?></span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Garages')); ?></h4>
                    <span><?php echo e($property->garage); ?></span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- <div class="carousel-item-b">
        <div class="card-box-a card-shadow">
          <div class="img-box-a">
            <img src="img/property-3.jpg" alt="" class="img-a img-fluid">
          </div>
          <div class="card-overlay">
            <div class="card-overlay-a-content">
              <div class="card-header-a">
                <h2 class="card-title-a">
                  <a href="property-single.html">157 West
                    <br /> Central Park</a>
                </h2>
              </div>
              <div class="card-body-a">
                <div class="price-box d-flex">
                  <span class="price-a">rent | $ 12.000</span>
                </div>
                <a href="property-single.html" class="link-a"><?php echo e(__('Click here to view')); ?>

                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
              <div class="card-footer-a">
                <ul class="card-info d-flex justify-content-around">
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Area')); ?></h4>
                    <span>340m
                      <sup>2</sup>
                    </span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Beds')); ?></h4>
                    <span>2</span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Baths')); ?></h4>
                    <span>4</span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Garages')); ?></h4>
                    <span>1</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div> -->
      <!-- <div class="carousel-item-b">
        <div class="card-box-a card-shadow">
          <div class="img-box-a">
            <img src="img/property-7.jpg" alt="" class="img-a img-fluid">
          </div>
          <div class="card-overlay">
            <div class="card-overlay-a-content">
              <div class="card-header-a">
                <h2 class="card-title-a">
                  <a href="property-single.html">245 Azabu
                    <br /> Nishi Park let</a>
                </h2>
              </div>
              <div class="card-body-a">
                <div class="price-box d-flex">
                  <span class="price-a">rent | $ 12.000</span>
                </div>
                <a href="property-single.html" class="link-a"><?php echo e(__('Click here to view')); ?>

                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
              <div class="card-footer-a">
                <ul class="card-info d-flex justify-content-around">
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Area')); ?></h4>
                    <span>340m
                      <sup>2</sup>
                    </span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Beds')); ?></h4>
                    <span>2</span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Baths')); ?></h4>
                    <span>4</span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Garages')); ?></h4>
                    <span>1</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div> -->
      <!-- <div class="carousel-item-b">
        <div class="card-box-a card-shadow">
          <div class="img-box-a">
            <img src="img/property-10.jpg" alt="" class="img-a img-fluid">
          </div>
          <div class="card-overlay">
            <div class="card-overlay-a-content">
              <div class="card-header-a">
                <h2 class="card-title-a">
                  <a href="property-single.html">204 Montal
                    <br /> South Bela Two</a>
                </h2>
              </div>
              <div class="card-body-a">
                <div class="price-box d-flex">
                  <span class="price-a">rent | $ 12.000</span>
                </div>
                <a href="property-single.html" class="link-a"><?php echo e(__('Click here to view')); ?>

                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
              <div class="card-footer-a">
                <ul class="card-info d-flex justify-content-around">
                  <li>
                    <h4 class="card-info-title">Area</h4>
                    <span>340m
                      <sup>2</sup>
                    </span>
                  </li>
                  <li>
                    <h4 class="card-info-title">Beds</h4>
                    <span>2</span>
                  </li>
                  <li>
                    <h4 class="card-info-title">Baths</h4>
                    <span>4</span>
                  </li>
                  <li>
                    <h4 class="card-info-title">Garages</h4>
                    <span>1</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div> -->
    </div>
  </div>
</section>
<!--/ Property End /-->
<?php /**PATH /home/u613105135/domains/real.pepsmartsolutions.com/public_html/resources/views/components/home/properties.blade.php ENDPATH**/ ?>