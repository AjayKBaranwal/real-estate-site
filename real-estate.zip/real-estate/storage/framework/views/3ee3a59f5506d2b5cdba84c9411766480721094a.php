<div class="row">
    <!-- basic table  -->
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header"><?php echo e(__('Table of properties')); ?></h5>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered first">
                        <thead>
                            <tr>
                                <th><?php echo e(__('City')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>
                                <th><?php echo e(__('Type')); ?></th>
                                <th><?php echo e(__('Price')); ?></th>
                                <th><?php echo e(__('Rent')); ?></th>
                                <th><?php echo e(__('Check')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($property->city); ?></td>
                                <td><?php echo e($property->status->status); ?></td>
                                <td><?php echo e($property->type->name); ?></td>
                                <td>$<?php echo e($property->price); ?></td>
                                <td>$<?php echo e($property->rent); ?></td>
                                <td>
                                  <a href="/home/property/<?php echo e($property->id); ?>">
                                    <?php echo e(__('Edit')); ?> <i class="pl-2 fas fa-edit"></i>
                                  </a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- end basic table  -->
</div>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/properties_table.blade.php ENDPATH**/ ?>