<!--/ Nav Star /-->
<nav class="navbar navbar-default navbar-trans navbar-expand-lg fixed-top">
  <div class="container">
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault"
      aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span></span>
      <span></span>
      <span></span>
    </button>
    <!--<a class="navbar-brand text-brand" href="/">Ranchi <span class="color-b">Real Estate</span></a>-->
	<a class="navbar-brand text-brand" href="/"><?php echo e(__('MyCompany')); ?></span></a>
    <button type="button" class="btn btn-link nav-search navbar-toggle-box-collapse d-md-none" data-toggle="collapse"
      data-target="#navbarTogglerDemo01" aria-expanded="false">
      <span class="fa fa-search" aria-hidden="true"></span>
    </button>
    <div class="navbar-collapse collapse justify-content-center" id="navbarDefault">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a
            class="nav-link <?php if(Request::segment(2) == ''): ?> active <?php endif; ?>"
            href="/">
            <?php echo e(__('Home')); ?>

          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link <?php if(Request::segment(2) == 'about'): ?> active <?php endif; ?>"
            href="/<?php echo e(app()->getLocale()); ?>/about">
            <?php echo e(__('About')); ?>

          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link <?php if(Request::segment(2) == 'properties'): ?> active <?php endif; ?>"
            href="/<?php echo e(app()->getLocale()); ?>/properties">
            <?php echo e(__('Villas')); ?>

          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link <?php if(Request::segment(2) == 'properties'): ?> active <?php endif; ?>"
            href="/<?php echo e(app()->getLocale()); ?>/properties">
            <?php echo e(__('Resorts')); ?>

          </a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link <?php if(Request::segment(2) == 'properties'): ?> active <?php endif; ?>"
            href="/<?php echo e(app()->getLocale()); ?>/properties">
            <?php echo e(__('Hotels')); ?>

          </a>
        </li>
        <li class="nav-item">
          <a
          class="nav-link nav-link <?php if(Request::segment(2) == 'contact'): ?> active <?php endif; ?>" 
          href="/<?php echo e(app()->getLocale()); ?>/contact">
            <?php echo e(__('Contact')); ?>

          </a>
        </li>
      </ul>
    </div>
    <button type="button" class="btn btn-b-n navbar-toggle-box-collapse d-none d-md-block" data-toggle="collapse"
      data-target="#navbarTogglerDemo01" aria-expanded="false">
      <span class="fa fa-search" aria-hidden="true"></span>
    </button>
  </div>
</nav>
<!--/ Nav End /-->
<?php /**PATH /home/u613105135/domains/real.pepsmartsolutions.com/public_html/resources/views/components/navigation.blade.php ENDPATH**/ ?>