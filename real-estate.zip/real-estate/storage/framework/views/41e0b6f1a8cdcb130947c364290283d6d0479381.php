<?php $__env->startSection('content'); ?>

<!-- Title  -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <h2><?php echo e(__('Agent')); ?> <?php echo e($agent->id); ?></h2>
    </div>
</div>

<div class="row">
  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
      <div class="card">
          <h5 class="card-header"><?php echo e(__('Agent data')); ?></h5>
          <div class="card-body">
              <?php if($errors->any()): ?>
                  <div class="alert alert-danger">
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
              <?php endif; ?>

              <?php if(session()->has('successMessage')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session()->get('successMessage')); ?>

                  </div>
              <?php endif; ?>

              <?php echo $__env->make('adminpanel.components.single-agent.textual-data-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
      </div>
  </div>

</div>

<?php echo $__env->make('adminpanel.components.single-agent.delete-agent-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
      <div class="card">
          <div class="card-body">
              <?php echo $__env->make('adminpanel.components.single-agent.image-data-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
      </div>
  </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminpanel.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/single-agent.blade.php ENDPATH**/ ?>