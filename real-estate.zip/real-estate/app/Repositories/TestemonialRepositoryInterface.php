<?php

namespace App\Repositories;

interface TestemonialRepositoryInterface extends EloquentRepositoryInterface {}
