<form id="deleteAgentForm" action="/home/agent" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('DELETE'); ?>
  <input name="id" value="<?php echo e($agent->id); ?>" style="display:none">
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/single-agent/delete-agent-form.blade.php ENDPATH**/ ?>