<form id="add-about-form" data-parsley-validate="" novalidate=""
  method="POST"
  enctype="multipart/form-data"
  action="/home/about">
  <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Title')); ?> (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-title" class="form-control"><?php if($about->count()): ?><?php echo e($about[0]->translate($language->iso)->title); ?><?php endif; ?></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Subtitle')); ?> (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-subtitle" class="form-control"><?php if($about->count()): ?><?php echo e($about[0]->translate($language->iso)->subtitle); ?><?php endif; ?></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Text')); ?> (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-text" class="form-control"><?php if($about->count()): ?><?php echo e($about[0]->translate($language->iso)->text); ?><?php endif; ?></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row mt-5">
        <div class="col-12">
          <h5 class="card-header p-0"><?php echo e(__('Upload images')); ?></h5>
        </div>
    </div>
    <?php if($about->count()): ?>
    <div class="row mt-4">
      <div class="col-12 col-md-6">
        <img src="<?php echo e(asset('images/about_images/horizontal/'.$about[0]->horizontal_image)); ?>" class="img-fluid" alt="">
      </div>
    </div>
    <?php endif; ?>
    <div class="form-group row mt-3">
      <div class="col-12">
        <label for="horizontal-image"><?php echo e(__('Select horizontal image')); ?> (image 1920 x 960):</label><br>
        <input type="file" id="horizontal-image" name="horizontal-image">
      </div>
    </div>
    <?php if($about->count()): ?>
    <div class="row mt-4">
      <div class="col-12 col-md-6">
        <img src="<?php echo e(asset('images/about_images/vertical/'.$about[0]->vertical_image)); ?>" class="img-fluid" alt="">
      </div>
    </div>
    <?php endif; ?>
    <div class="form-group row mt-3">
      <div class="col-12">
        <label for="vertical-image"><?php echo e(__('Select vertical image')); ?> (image 600 x 800):</label><br>
        <input type="file" id="vertical-image" name="vertical-image">
      </div>
    </div>
    <div class="form-group row text-right">
        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
            <button
              type="submit"
              class="btn btn-space btn-primary">
              <?php echo e(__('Save')); ?>

            </button>
        </div>
    </div>
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/about/form.blade.php ENDPATH**/ ?>