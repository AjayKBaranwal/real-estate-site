<!--/ Property Single Star /-->
<section class="property-single nav-arrow-b">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div id="property-single-carousel" class="owl-carousel owl-arrow gallery-property">
          <?php $__currentLoopData = $property->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item-b">
              <img src="<?php echo e(asset('images/property_images/horizontal_images/'.$image->filename)); ?>" alt="">
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row justify-content-between">
          <div class="col-md-5 col-lg-4">
            <div class="property-price d-flex justify-content-center foo">
              <div class="card-header-c d-flex">
                <div class="card-box-ico">
                  <span class="ion-money">$</span>
                </div>
                <div class="card-title-c align-self-center">
                  <h5 class="title-c"><?php echo e($property->price); ?></h5>
                </div>
              </div>
            </div>
            <div class="property-summary">
              <div class="row">
                <div class="col-sm-12">
                  <div class="title-box-d section-t4">
                    <h3 class="title-d"><?php echo e(__('Quick Summary')); ?></h3>
                  </div>
                </div>
              </div>
              <div class="summary-list">
                <ul class="list">
                  <li class="d-flex justify-content-between">
                    <strong><?php echo e(__('Location')); ?>:</strong>
                    <span><?php echo e($property->city); ?></span>
                  </li>
                  <li class="d-flex justify-content-between">
                    <strong><?php echo e(__('Property Type')); ?>:</strong>
                    <span><?php echo e($property->type->name); ?></span>
                  </li>
                  <li class="d-flex justify-content-between">
                    <strong><?php echo e(__('Status')); ?>:</strong>
                    <span><?php echo e($property->status->status); ?></span>
                  </li>
                  <li class="d-flex justify-content-between">
                    <strong><?php echo e(__('Area')); ?>:</strong>
                    <span><?php echo e($property->area); ?>m
                      <sup>2</sup>
                    </span>
                  </li>
                  <li class="d-flex justify-content-between">
                    <strong><?php echo e(__('Beds')); ?>:</strong>
                    <span><?php echo e($property->beds); ?></span>
                  </li>
                  <li class="d-flex justify-content-between">
                    <strong><?php echo e(__('Baths')); ?>:</strong>
                    <span><?php echo e($property->baths); ?></span>
                  </li>
                  <li class="d-flex justify-content-between">
                    <strong><?php echo e(__('Garage')); ?>:</strong>
                    <span><?php echo e($property->garage); ?></span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-7 col-lg-7 section-md-t3">
            <div class="row">
              <div class="col-sm-12">
                <div class="title-box-d">
                  <h3 class="title-d"><?php echo e(__('Property Description')); ?></h3>
                </div>
              </div>
            </div>
            <div class="property-description">
              <?php $__currentLoopData = explode("\n", $property->description); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <p class="description color-text-a">
                <?php echo e($paragraph); ?>

              </p>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row section-t3">
              <div class="col-sm-12">
                <div class="title-box-d">
                  <h3 class="title-d"><?php echo e(__('Amenities')); ?></h3>
                </div>
              </div>
            </div>
            <div class="amenities-list color-text-a">
              <ul class="list-a no-margin">
                <?php if($property->amenities->count() == 0): ?>
                <p><?php echo e(__('No amenities')); ?></p>
                <?php endif; ?>
                <?php $__currentLoopData = $property->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($amenity->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- Agent start -->
      <?php if($property->agent): ?>
      <div class="col-md-12">
        <div class="row section-t3">
          <div class="col-sm-12">
            <div class="title-box-d">
              <h3 class="title-d"><?php echo e(__('Contact Agent')); ?></h3>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4">
            <img src="<?php echo e(asset('images/agent_images/'.$property->agent->image)); ?>" alt="" class="img-fluid">
          </div>
          <div class="col-md-6 col-lg-4">
            <div class="property-agent">
              <h4 class="title-agent"><?php echo e($property->agent->full_name); ?></h4>
              <p class="color-text-a">
                <?php echo e($property->agent->about); ?>

              </p>
              <ul class="list-unstyled">
                <li class="d-flex justify-content-between">
                  <strong><?php echo e(__('Phone')); ?>:</strong>
                  <span class="color-text-a"><?php echo e($property->agent->phone); ?></span>
                </li>
                <li class="d-flex justify-content-between">
                  <strong><?php echo e(__('Email')); ?>:</strong>
                  <span class="color-text-a"><?php echo e($property->agent->email); ?></span>
                </li>
              </ul>
              <div class="socials-a">
                <ul class="list-inline">
                  <li class="list-inline-item">
                    <a href="#">
                      <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#">
                      <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#">
                      <i class="fa fa-instagram" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#">
                      <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#">
                      <i class="fa fa-dribbble" aria-hidden="true"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

        </div>
      </div>
      <?php endif; ?>
      <!-- End agent -->
    </div>
  </div>
</section>
<!--/ Property Single End /-->
<div class="whatsup-icon">
  <a href="https://wa.me/+917022118160?text=Hi, enquiry for <?php echo e($property->house_number); ?> <?php echo e($property->street_name); ?>" target="_blank"><img src="/storage/whatsup-icon.png" alt="whatsup-logo" width="64px" height="64px"></a>
</div>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/components/single-property/details.blade.php ENDPATH**/ ?>