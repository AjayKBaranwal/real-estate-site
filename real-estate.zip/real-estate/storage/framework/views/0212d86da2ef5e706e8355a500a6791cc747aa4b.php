<!--/ Agents Grid Star /-->
<section class="agents-grid grid">
  <div class="container">
    <div class="row">
      <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="card-box-d">
          <div class="card-img-d">
            <img src="<?php echo e(asset('images/agent_images').'/'.$agent->image); ?>" alt="" class="img-d img-fluid">
          </div>
          <div class="card-overlay card-overlay-hover">
            <div class="card-header-d">
              <div class="card-title-d align-self-center">
                <h3 class="title-d">
                  <a href="/<?php echo e(app()->currentLocale()); ?>/agent/<?php echo e($agent->id); ?>" class="link-two">
                    <?php echo e($agent->full_name); ?>

                  </a>
                </h3>
              </div>
            </div>
            <div class="card-body-d">
              <p class="content-d color-text-a">
                <?php echo e($agent->shortAbout()); ?>

              </p>
              <div class="info-agents color-a">
                <p>
                  <strong><?php echo e(__('Phone')); ?>: </strong> <?php echo e($agent->phone); ?></p>
                <p>
                  <strong><?php echo e(__('Email')); ?>: </strong> <?php echo e($agent->email); ?></p>
              </div>
            </div>
            <div class="card-footer-d">
              <div class="socials-footer d-flex justify-content-center">
                <ul class="list-inline">
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-instagram" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                    </a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="link-one">
                      <i class="fa fa-dribbble" aria-hidden="true"></i>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row">
      <?php echo e($agents->links()); ?>

    </div>
  </div>
</section>
<!--/ Agents Grid End /-->
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/components/agents/agents_grid.blade.php ENDPATH**/ ?>