<!-- Update pop up -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Delete')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php echo e(__('Are you sure you want to delete?')); ?>

      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
          <button
            type="button"
            onclick="event.preventDefault(); document.getElementById('deleteAgentForm').submit();"
            class="btn btn-danger">
            <?php echo e(__('Delete')); ?>

          </button>
      <div>
    </div>
  </div>
</div>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/single-agent/delete-pop-up.blade.php ENDPATH**/ ?>