@extends('layouts.main')

@section('content')

  @include('components.form-search')
  @include('components.contact.intro')
  @include('components.contact.info')

@stop
