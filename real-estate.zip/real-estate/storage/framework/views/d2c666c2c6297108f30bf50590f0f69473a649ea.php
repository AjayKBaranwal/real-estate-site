<!--/ Intro Single star /-->
<section class="intro-single">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8">
        <div class="title-single-box">
          <h1 class="title-single"><?php echo e(__('Our Amazing Agents')); ?></h1>
          <span class="color-text-a"><?php echo e(__('MyCompany Agents')); ?></span>
        </div>
      </div>
      <div class="col-md-12 col-lg-4">
        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="/<?php echo e(app()->currentLocale()); ?>/">
                <?php echo e(__('Home')); ?>

              </a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
              <?php echo e(__('All Agents')); ?>

            </li>
          </ol>
        </nav>
      </div>
    </div>
  </div>
</section>
<!--/ Intro Single End /-->
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/components/agents/intro.blade.php ENDPATH**/ ?>