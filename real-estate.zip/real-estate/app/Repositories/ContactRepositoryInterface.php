<?php

namespace App\Repositories;

interface ContactRepositoryInterface extends EloquentRepositoryInterface {}
