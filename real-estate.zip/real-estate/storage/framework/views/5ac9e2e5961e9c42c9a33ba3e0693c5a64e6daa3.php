<form id="deleteTestemonialForm" action="/home/testemonial" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('DELETE'); ?>
  <input name="id" value="<?php echo e($testemonial->id); ?>" style="display:none">
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/single-testemonial/delete-testemonial-form.blade.php ENDPATH**/ ?>