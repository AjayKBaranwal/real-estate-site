<!--/ Property Grid Star /-->
<section class="property-grid grid">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="grid-option">
          <form action="/<?php echo e(app()->getLocale()); ?>/properties" method="GET" id="filter">
            <?php echo csrf_field(); ?>
            <select class="custom-select" name="status">
              <option
               class="filter"
               value="All"
               <?php if($current_status_filter == null): ?> selected <?php endif; ?>>
                <?php echo e(__('All')); ?>

              </option>
              <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option
                    value="<?php echo e($status->status_id); ?>"
                    <?php if($current_status_filter == $status->status_id): ?> selected <?php endif; ?>
                    class="filter">
                      <?php echo e($status->status); ?>

                  </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </form>
        </div>
      </div>

      <?php if($properties->count() == 0): ?>
        <p><?php echo e(__('No results for this search')); ?></p>
      <?php endif; ?>

      <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="card-box-a card-shadow">
          <div class="img-box-a">
            <img src="<?php echo e(asset('/public/images/property_images/vertical_images/'.$property->vertical_image)); ?>" alt="" class="img-a img-fluid">
          </div>
          <div class="card-overlay">
            <div class="card-overlay-a-content">
              <div class="card-header-a">
                <h2 class="card-title-a">
                  <a href="/<?php echo e(app()->getLocale()); ?>/property/<?php echo e($property->id); ?>">
                    <?php echo e($property->house_number); ?><br />
                    <?php echo e($property->street_name); ?></a>
                </h2>
              </div>
              <div class="card-body-a">
                <div class="price-box d-flex">
                  <span class="price-a">rent | $ <?php echo e($property->rent); ?></span>
                </div>
                <a href="/<?php echo e(app()->getLocale()); ?>/property/<?php echo e($property->id); ?>" class="link-a">
                  <?php echo e(__('Click here to view')); ?>

                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
              <div class="card-footer-a">
                <ul class="card-info d-flex justify-content-around">
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Area')); ?></h4>
                    <span><?php echo e($property->area); ?>m
                      <sup>2</sup>
                    </span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Beds')); ?></h4>
                    <span><?php echo e($property->beds); ?></span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Baths')); ?></h4>
                    <span><?php echo e($property->baths); ?></span>
                  </li>
                  <li>
                    <h4 class="card-info-title"><?php echo e(__('Garages')); ?></h4>
                    <span><?php echo e($property->garage); ?></span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="row">
    <?php echo e($properties->links()); ?>

  </div>
</section>
<!--/ Property Grid End /-->
<?php /**PATH /home/u613105135/domains/real.pepsmartsolutions.com/public_html/resources/views/components/properties/property_grid.blade.php ENDPATH**/ ?>