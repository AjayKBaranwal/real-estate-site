<div class="row">
    <!-- basic table  -->
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <h5 class="card-header"><?php echo e(__('Table of properties')); ?></h5>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered first">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Names')); ?></th>
                                <th><?php echo e(__('Text')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $testemonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testemonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($testemonial->names); ?></td>
                                <td><?php echo e($testemonial->text); ?></td>
                                <td>
                                  <a href="/home/testemonial/<?php echo e($testemonial->id); ?>">
                                    <?php echo e(__('Edit')); ?> <i class="pl-2 fas fa-edit"></i>
                                  </a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- end basic table  -->
</div>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/testemonials_table.blade.php ENDPATH**/ ?>