<form id="testemonial-form" data-parsley-validate="" novalidate=""
  method="POST"
  action="/home/testemonial/<?php echo e($testemonial->id); ?>">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
    <div class="form-group">
      <div style="display:none">
        <input value="<?php echo e($testemonial->id); ?>" name="testemonialId" class="form-control">
      </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Name(s)')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php echo e($testemonial->names); ?>" name="names" type="text" placeholder="names" class="form-control">
        </div>
    </div>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Text')); ?> (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-text" class="form-control"><?php echo e($testemonial->translate($language->iso)->text); ?></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row text-right">
        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
            <button
              type="button"
              class="btn btn-space btn-primary"
              data-toggle="modal" data-target="#updateModal">
              <?php echo e(__('Update')); ?>

            </button>
            <button
              type="button"
              data-toggle="modal" data-target="#deleteModal"
              class="btn btn-space btn-secondary">
              <?php echo e(__('Delete testemonial')); ?>

            </button>

            <?php echo $__env->make('adminpanel.components.single-testemonial.update-pop-up', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('adminpanel.components.single-testemonial.delete-pop-up', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/single-testemonial/textual-data-form.blade.php ENDPATH**/ ?>