<?php

namespace App\Repositories;

interface AmenityPropertyRepositoryInterface extends EloquentRepositoryInterface {}
