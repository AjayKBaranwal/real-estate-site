<!--/ footer Star /-->
<section class="section-footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-4">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand"><?php echo e(__('MyCompany')); ?></h3>
          </div>
          <div class="w-body-a">
            <p class="w-text-a color-text-a">
              Enim minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat duis
              sed aute irure.
            </p>
          </div>
          <div class="w-footer-a">
            <?php if(count($contact)): ?>
            <ul class="list-unstyled">
              <li class="color-a">
                <span class="color-text-a"><?php echo e(__('Email')); ?> .</span> <?php echo e($contact[0]->email); ?></li>
              <li class="color-a">
                <span class="color-text-a"><?php echo e(__('Phone')); ?> .</span> <?php echo e($contact[0]->phone); ?></li>
            </ul>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="col-sm-12 col-md-4 section-md-t3">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand"><?php echo e(__('The Company')); ?></h3>
          </div>
          <div class="w-body-a">
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                  <i class="fa fa-angle-right"></i> <a href="/login">Admin</a>
                </li>
                <li class="item-list-a">
                  <i class="fa fa-angle-right"></i>
                  <a href="/<?php echo e(app()->currentLocale()); ?>/agents">
                    <?php echo e(__('Agents')); ?>

                  </a>
                </li>
                <li class="item-list-a">
                  <i class="fa fa-angle-right"></i> <a href="/<?php echo e(app()->getLocale()); ?>/about"><?php echo e(__('About')); ?></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-12 col-md-4 section-md-t3">
        <div class="widget-a">
          <div class="w-header-a">
            <h3 class="w-title-a text-brand"><?php echo e(__('Site Languages')); ?></h3>
          </div>
          <div class="w-body-a">
            <ul class="list-unstyled">
              <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="item-list-a">
                <i class="fa fa-angle-right"></i> <a href="/<?php echo e($language->iso); ?>">
                  <?php echo e(strtoupper($language->iso)); ?></a>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <nav class="nav-footer">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="/<?php echo e(app()->currentLocale()); ?>/">
                <?php echo e(__('Home')); ?>

              </a>
            </li>
            <li class="list-inline-item">
              <a href="/<?php echo e(app()->currentLocale()); ?>/about">
                <?php echo e(__('About')); ?>

              </a>
            </li>
            <li class="list-inline-item">
              <a href="/<?php echo e(app()->currentLocale()); ?>/properties"><?php echo e(__('Property')); ?></a>
            </li>
            <li class="list-inline-item">
              <a href="/<?php echo e(app()->currentLocale()); ?>/contact">
                <?php echo e(__('Contact')); ?>

              </a>
            </li>
          </ul>
        </nav>
        <div class="socials-a">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="#">
                <i class="fa fa-facebook" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fa fa-twitter" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fa fa-instagram" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fa fa-pinterest-p" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="#">
                <i class="fa fa-dribbble" aria-hidden="true"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="copyright-footer">
          <p class="copyright color-text-a">
            &copy; Copyright
            <span class="color-a"><?php echo e(__('MyCompany')); ?></span> All Rights Reserved.
          </p>
        </div>
        <div>
          Designed with Bootstrap
        </div>
      </div>
    </div>
  </div>
</footer>
<!--/ Footer End /-->

<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
<div id="preloader"></div>

<!-- JavaScript Libraries -->
<script src="/lib/jquery/jquery.min.js"></script>
<script src="/lib/jquery/jquery-migrate.min.js"></script>
<script src="/lib/popper/popper.min.js"></script>
<script src="/lib/bootstrap/js/bootstrap.min.js"></script>
<script src="/lib/easing/easing.min.js"></script>
<script src="/lib/owlcarousel/owl.carousel.min.js"></script>
<script src="/lib/scrollreveal/scrollreveal.min.js"></script>

<!-- Template Main Javascript File -->
<script src="/js/main.js"></script>
<script src="/js/app.js"></script>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/components/footer.blade.php ENDPATH**/ ?>