<!--/ Carousel Star /-->
<div class="intro intro-carousel">
  <div id="carousel" class="owl-carousel owl-theme">
    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="carousel-item-a intro-item bg-image" style="background-image: url(<?php echo e(asset('/public/images/property_images/horizontal_images/'.$property->images[0]->filename)); ?>)">
      <div class="overlay overlay-a"></div>
      <div class="intro-content display-table">
        <div class="table-cell">
          <div class="container">
            <div class="row">
              <div class="col-lg-8">
                <div class="intro-body">
                  <p class="intro-title-top"><?php echo e($property->city); ?>

                    </p>
                    <h1 class="intro-title mb-4">
                      <span class="color-b"><?php echo e($property->house_number); ?> </span>
                      <br><?php echo e($property->street_name); ?></h1>
                  <p class="intro-subtitle intro-price">
                    <a href="#"><span class="price-a">rent | $ <?php echo e($property->rent); ?></span></a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!--/ Carousel end /-->
<?php /**PATH /home/u613105135/domains/real.pepsmartsolutions.com/public_html/resources/views/components/home/carousel.blade.php ENDPATH**/ ?>