<!--/ Testimonials Star /-->
<section class="section-testimonials section-t8 nav-arrow-a">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="title-wrap d-flex justify-content-between">
          <div class="title-box">
            <h2 class="title-a"><?php echo e(__('Testimonials')); ?></h2>
          </div>
        </div>
      </div>
    </div>
    <div id="testimonial-carousel" class="owl-carousel owl-arrow">
      <?php $__currentLoopData = $testemonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testemonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item-a">
        <div class="testimonials-box">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div class="testimonial-img">
                <img src="<?php echo e(asset('/public/images/testemonial_images/'.$testemonial->image_filename)); ?>" alt="" class="img-fluid">
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              <div class="testimonial-ico">
                <span class="ion-ios-quote"></span>
              </div>
              <div class="testimonials-content">
                <p class="testimonial-text">
                  <?php echo e($testemonial->text); ?>

                </p>
              </div>
              <div class="testimonial-author-box">
                <img src="<?php echo e(asset('/public/images/testemonial_images/mini/'.$testemonial->mini_image_filename)); ?>" alt="" class="testimonial-avatar">
                <h5 class="testimonial-author"><?php echo e($testemonial->names); ?></h5>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<!--/ Testimonials End /-->
<?php /**PATH /home/u613105135/domains/real.pepsmartsolutions.com/public_html/resources/views/components/home/testemonials.blade.php ENDPATH**/ ?>