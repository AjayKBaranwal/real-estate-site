<?php

namespace App\Repositories;

interface AmenityRepositoryInterface extends EloquentRepositoryInterface {}
