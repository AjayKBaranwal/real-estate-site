    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Street name')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="street_name" type="text" placeholder="Street name" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('House number')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="house_number" type="number" placeholder="Number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('City')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" type="text" name="city" placeholder="Max 50 chars." class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Price')); ?> (USD)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="price" type="number" placeholder="Number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Area')); ?> (m<sup>2</sup>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="area" type="number" placeholder="Number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Beds')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="beds" type="number" placeholder="Number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Baths')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="baths" type="number" placeholder="Number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Garage')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="garage" type="number" placeholder="Number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Rent')); ?> (USD)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="rent" type="number" placeholder="Number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-3 col-form-label text-sm-right"><?php echo e(__('Status')); ?></label>
        <div class="col-sm-6">
            <div class="custom-controls-stacked">
              <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="custom-control custom-checkbox">
                    <input
                    <?php if($statuses[0]->status == $status->status): ?>
                    checked
                    <?php endif; ?>
                    name="status" type="radio" data-parsley-multiple="groups" value="<?php echo e($status->status_id); ?>" data-parsley-mincheck="2" data-parsley-errors-container="#error-container1" class="custom-control-input">
                    <span class="custom-control-label"><?php echo e($status->status); ?></span>
                </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="error-container1"></div>
            </div>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-3 col-form-label text-sm-right"><?php echo e(__('Type')); ?></label>
        <div class="col-sm-6">
            <div class="custom-controls-stacked">
              <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <label class="custom-control custom-checkbox">
                  <input type="radio"
                  <?php if($types[0]->id == $type->id): ?>
                    checked
                  <?php endif; ?>
                  value="<?php echo e($type->id); ?>" name="type" data-parsley-multiple="group1" data-parsley-errors-container="#error-container2" class="custom-control-input">
                  <span class="custom-control-label"><?php echo e($type->name); ?></span>
              </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="error-container2"></div>
            </div>
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-3 col-form-label text-sm-right"><?php echo e(__('Agent')); ?></label>
        <div class="col-sm-6">
            <div class="custom-controls-stacked">
              <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="custom-control custom-checkbox">
                    <input
                    <?php if($agents[0]->id == $agent->id): ?>
                      checked
                    <?php endif; ?>
                    type="radio" value="<?php echo e($agent->id); ?>" name="agent" data-parsley-multiple="group1" data-parsley-errors-container="#error-container2" class="custom-control-input">
                    <span class="custom-control-label"><?php echo e($agent->full_name); ?></span>
                </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="error-container2"></div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right">About (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-description" class="form-control"></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="form-group row">
        <label class="col-sm-3 col-form-label text-sm-right"><?php echo e(__('Amenities')); ?></label>
        <div class="col-sm-6">
            <div class="custom-controls-stacked">
              <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="custom-control custom-checkbox">
                    <input
                    <?php if($amenities[0]->id == $amenity->id): ?>
                    checked
                    <?php endif; ?>
                    type="checkbox" value="<?php echo e($amenity->id); ?>" name="amenity<?php echo e($amenity->id); ?>" data-parsley-multiple="group1" data-parsley-errors-container="#error-container2" class="custom-control-input">
                    <span class="custom-control-label"><?php echo e($amenity->name); ?></span>
                </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="error-container2"></div>
            </div>
        </div>
    </div>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/add-property/textual-data.blade.php ENDPATH**/ ?>