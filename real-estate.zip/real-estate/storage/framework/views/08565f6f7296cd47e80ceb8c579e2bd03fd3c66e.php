<!--/ About Star /-->
<section class="section-about">
  <div class="container">
    <div class="row">
      <?php if($about && $about->horizontal_image): ?>
      <div class="col-sm-12">
        <div class="about-img-box">
          <img src="<?php echo e(asset('images/about_images/horizontal/'.$about->horizontal_image)); ?>" alt="" class="img-fluid">
        </div>
        <div class="sinse-box">
          <h3 class="sinse-title"><?php echo e(__('MyCompany')); ?>

            <span></span>
            <br> <?php echo e(__('Sinse 2017')); ?></h3>
          <p><?php echo e(__('Art & Creative')); ?></p>
        </div>
      </div>
      <?php endif; ?>
      <div class="col-md-12 section-t8">
        <div class="row">
          <?php if($about && $about->vertical_image): ?>
          <div class="col-md-6 col-lg-5">
            <img src="<?php echo e(asset('images/about_images/vertical/'.$about->vertical_image)); ?>" alt="" class="img-fluid">
          </div>
          <?php endif; ?>
          <div class="col-lg-2  d-none d-lg-block">
            <div class="title-vertical d-flex justify-content-start">
              <!-- <span><?php echo e(__('MyCompany')); ?> <?php echo e(__('Exclusive Property')); ?></span> -->
            </div>
          </div>
          <?php if($about): ?>
          <div class="col-md-6 col-lg-5 section-md-t3">
            <div class="title-box-d">
              <h3 class="title-d"><?php echo e($about->subtitle); ?></h3>
            </div>
            <?php $__currentLoopData = explode("\n", $about->text); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <p class="color-text-a">
                <?php echo e($paragraph); ?>

              </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ About End /-->
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/components/about/about-section.blade.php ENDPATH**/ ?>