<form id="agent-form" data-parsley-validate="" novalidate=""
  method="POST"
  action="/home/agent/<?php echo e($agent->id); ?>">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
    <div class="form-group">
      <div style="display:none">
        <input value="<?php echo e($agent->id); ?>" name="agentId" class="form-control">
      </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Full name')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php echo e($agent->full_name); ?>" name="full_name" type="text" placeholder="Full name" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Phone number')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php echo e($agent->phone); ?>" name="phone" type="text" placeholder="Phone number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Email')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php echo e($agent->email); ?>" type="email" name="email" placeholder="Email" class="form-control">
        </div>
    </div>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('About')); ?> (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-description" class="form-control"><?php echo e($agent->translate($language->iso)->about); ?></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-sm-3 col-form-label text-sm-right"><?php echo e(__('Properties')); ?></label>
        <div class="col-sm-6">
            <div class="custom-controls-stacked">
              <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="custom-control custom-checkbox">
                    <input
                    <?php if($agent->hasThisProperty($property)): ?>
                    checked
                    <?php endif; ?>
                    type="checkbox" value="<?php echo e($property->id); ?>" name="property<?php echo e($property->id); ?>" data-parsley-multiple="group1" data-parsley-errors-container="#error-container2" class="custom-control-input">
                    <span class="custom-control-label"><?php echo e($property->city); ?>, <?php echo e($property->street_name); ?>, <?php echo e($property->house_number); ?></span>
                </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="error-container2"></div>
            </div>
        </div>
    </div>
    <div class="form-group row text-right">
        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
            <button
              type="button"
              class="btn btn-space btn-primary"
              data-toggle="modal" data-target="#updateModal">
              <?php echo e(__('Update')); ?>

            </button>
            <button
              type="button"
              data-toggle="modal" data-target="#deleteModal"
              class="btn btn-space btn-secondary">
              <?php echo e(__('Delete agent')); ?>

            </button>

            <?php echo $__env->make('adminpanel.components.single-agent.update-pop-up', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('adminpanel.components.single-agent.delete-pop-up', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/single-agent/textual-data-form.blade.php ENDPATH**/ ?>