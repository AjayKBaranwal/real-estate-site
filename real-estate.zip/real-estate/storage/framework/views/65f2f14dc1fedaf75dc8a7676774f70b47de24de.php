<?php if($paginator->hasPages()): ?>
<div class="col-sm-12">
  <nav class="pagination-a">
    <ul class="pagination justify-content-end">

      
      <?php if($paginator->onFirstPage()): ?>
        <li class="page-item disabled">
          <a class="page-link" tabindex="-1">
            <span class="ion-ios-arrow-back"></span>
          </a>
        </li>
      <?php else: ?>
        <li class="page-item">
          <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" tabindex="-1">
            <span class="ion-ios-arrow-back"></span>
          </a>
        </li>
      <?php endif; ?>

      
      <?php if(is_array($elements[0])): ?>
        <?php $__currentLoopData = $elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($page == $paginator->currentPage()): ?>
            <li class="page-item active">
              <a class="page-link"><?php echo e($page); ?></a>
            </li>
          <?php else: ?>
            <li class="page-item">
              <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
            </li>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>

      
      <?php if($paginator->hasMorePages()): ?>
        <li class="page-item next">
          <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>">
            <span class="ion-ios-arrow-forward"></span>
          </a>
        </li>
      <?php else: ?>
        <li class="page-item next disabled">
          <a class="page-link">
            <span class="ion-ios-arrow-forward"></span>
          </a>
        </li>
      <?php endif; ?>

    </ul>
  </nav>
</div>
<?php endif; ?>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>