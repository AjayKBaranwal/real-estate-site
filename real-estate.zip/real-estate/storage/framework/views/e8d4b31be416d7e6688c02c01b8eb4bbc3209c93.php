<form id="add-agent-form" data-parsley-validate="" novalidate=""
  method="POST"
  enctype="multipart/form-data"
  action="/home/agent/">
  <?php echo csrf_field(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Full name')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="full_name" type="text" placeholder="Full name" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Phone number')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" name="phone" type="text" placeholder="Phone number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Email')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="" type="email" name="email" placeholder="Email" class="form-control">
        </div>
    </div>
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('About')); ?> (<?php echo e(strtoupper($language->iso)); ?>)</label>
        <div class="col-12 col-sm-8 col-lg-6">
            <textarea name="<?php echo e($language->iso); ?>-description" class="form-control"></textarea>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">
        <label class="col-sm-3 col-form-label text-sm-right"><?php echo e(__('Properties')); ?></label>
        <div class="col-sm-6">
            <div class="custom-controls-stacked">
              <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="custom-control custom-checkbox">
                    <input
                    type="checkbox" value="<?php echo e($property->id); ?>" name="property<?php echo e($property->id); ?>" data-parsley-multiple="group1" data-parsley-errors-container="#error-container2" class="custom-control-input">
                    <span class="custom-control-label"><?php echo e($property->city); ?>, <?php echo e($property->street_name); ?>, <?php echo e($property->house_number); ?></span>
                </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div id="error-container2"></div>
            </div>
        </div>
    </div>
    <div class="form-group row">
      <div class="custom-file mb-3 col-10 col-md-6 ml-auto mr-auto">
          <input type="file" name="image" class="custom-file-input" id="customFile">
          <label class="custom-file-label" for="customFile">Select image (800x896)</label>
      </div>
    </div>
    <div class="form-group row text-right">
        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
            <button
              type="submit"
              class="btn btn-space btn-primary">
              <?php echo e(__('Save')); ?>

            </button>
        </div>
    </div>
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/add-agent/form.blade.php ENDPATH**/ ?>