<form id="add-contact-form" data-parsley-validate="" novalidate=""
  method="POST"
  action="/home/contact">
  <?php echo csrf_field(); ?>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Email')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php if($contact->count()): ?><?php echo e($contact[0]->email); ?><?php endif; ?>" placeholder="email" name="email" class="form-control" type="email" />
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Phone')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php if($contact->count()): ?><?php echo e($contact[0]->phone); ?><?php endif; ?>" placeholder="phone" name="phone" class="form-control" type="number" />
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('City')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php if($contact->count()): ?><?php echo e($contact[0]->city); ?><?php endif; ?>" placeholder="city" name="city" class="form-control" />
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('Street name')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php if($contact->count()): ?><?php echo e($contact[0]->street_name); ?><?php endif; ?>" placeholder="street name" name="street_name" class="form-control" />
        </div>
    </div>
    <div class="form-group row">
        <label class="col-12 col-sm-3 col-form-label text-sm-right"><?php echo e(__('House number')); ?></label>
        <div class="col-12 col-sm-8 col-lg-6">
            <input value="<?php if($contact->count()): ?><?php echo e($contact[0]->house_number); ?><?php endif; ?>" placeholder="house number" name="house_number" class="form-control" />
        </div>
    </div>
    <div class="form-group row text-right">
        <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
            <button
              type="submit"
              class="btn btn-space btn-primary">
              <?php echo e(__('Save')); ?>

            </button>
        </div>
    </div>
</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/contact/form.blade.php ENDPATH**/ ?>