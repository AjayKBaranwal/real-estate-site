<div class="row">
  <div class="col-12">
    <h2><?php echo e(__('Agent vertical image')); ?></h2>
  </div>
</div>

<div class="row">
  <div class="col-12 col-md-6">
    <img src="<?php echo e(asset('images/agent_images/'.$agent->image)); ?>" class="img-fluid" alt="">
  </div>
</div>

<form
  action="/home/agent/image"
  enctype="multipart/form-data"
  method="post">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>

  <div class="form-group row mt-3">
    <div class="col-12">
      <label for="vertical-image"><?php echo e(__('Select a file')); ?> (image 800 x 890):</label><br>
      <input type="file" id="image" name="image">
      <input type="hidden" name="agentId" value="<?php echo e($agent->id); ?>">
    </div>
  </div>

  <div class="row mt-3">
    <div class="col-12">
      <button
        type="submit"
        class="btn btn-space btn-primary">
        <?php echo e(__('Change image')); ?>

      </button>
    </div>
  </div>

</form>
<?php /**PATH C:\projects\laravel\real-estate-site\resources\views/adminpanel/components/single-agent/image-data-form.blade.php ENDPATH**/ ?>