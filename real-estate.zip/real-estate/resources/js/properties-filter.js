$('.custom-select').change(function(){
    $( "#filter" ).submit();
});
